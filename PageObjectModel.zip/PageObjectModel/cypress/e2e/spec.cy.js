import LoginPage from "../support/pageObjectModel/LoginPage";
import ProductPage from "../support/pageObjectModel/ProductPage";
import CartPage from "../support/pageObjectModel/CartPage";
import CheckOutPage from "../support/pageObjectModel/CheckOutPage";
describe('Pom', () => {

  const loginpage = new LoginPage();
  const productpage = new ProductPage();
  const cartpage  = new CartPage();
  const checkoutpage = new CheckOutPage();
  it('Login', () => {
    loginpage.LoginPage();
    productpage.ProductPage();
    cartpage.CartPage();
    checkoutpage.CheckOutPage();
  });
});