class CartPage{
    CartPage(){
        cy.visit('https://automationteststore.com');
        cy.xpath('(//a[@href="#"])[1]').click();

    }
}
export default CartPage