class CheckOutPage{
    CheckOutPage(){
    cy.visit('https://automationteststore.com');
    cy.xpath('//a[@id="cart_checkout1"]').click();
    cy.xpath('//button[@id="checkout_btn"]').click();
    }
}
export default CheckOutPage