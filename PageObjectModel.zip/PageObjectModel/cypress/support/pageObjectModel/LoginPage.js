class LoginPage{
    LoginPage(){
    cy.visit('https://automationteststore.com');
    //cy.get('(href="https://automationteststore.com/index.php?rt=account/login")[1]').click();
    cy.get('#customer_menu_top>li>a').click();
    cy.xpath('//input[@id="loginFrm_loginname"]').type("Shubham20");
    cy.xpath('//input[@id="loginFrm_password"]').type("Shubham@0808");
    cy.xpath('(//button[@type="submit"])[2]').click();
    
    }
}
export default LoginPage