class ProductPage{
    ProductPage(){
        cy.visit('https://automationteststore.com')
        cy.xpath('(//input[@type="text"])[1]').type('skincare');
        cy.xpath('//i[@class="fa fa-search"]').click();
        cy.xpath('(//a[@class="productname"])[3]').click();
        cy.xpath('//input[@id="product_quantity"]').clear().type(2);
    }
}
export default ProductPage