import RegisterPage from "../support/Page Object Model/RegisterPage";
import LoginPage from "../support/Page Object Model/LoginPage";
import Homepage from "../support/Page Object Model/Homepage";
import NavDesktop from "../support/Page Object Model/NavDesktop";
import searchBar from "../support/Page Object Model/searchBar";
//import Homepage from "../support/Page Object Model/Homepage";
//import NavDesktop from "../support/Page Object Model/NavDesktop";
import LaptopsNotebooks from "../support/Page Object Model/NavLaptopsAndNotebooks";
import NavComponents from "../support/Page Object Model/NavComponents";
import NavTablets from "../support/Page Object Model/NavTablets";
import NavSoftware from "../support/Page Object Model/NavSoftware";
import NavPhonesAndPDAs from "../support/Page Object Model/NavphonesAndPDAs";
import NavCamera from "../support/Page Object Model/NavCamera";
import NavMP3Player from "../support/Page Object Model/NavMP3Player";
import checkout from "../support/Page Object Model/checkout";
import Infomation from "../support/Page Object Model/Infomation";
import LogoutPage from "../support/Page Object Model/LogoutPage";

describe('Tutorials Ninja', () => {
  const register_obj = new RegisterPage();
  const login_obj1 = new LoginPage();
  const homepage_obj = new Homepage();
  //const desktop_obj1= new NavDesktop();
  const search_obj = new searchBar();
  const login_obj = new Homepage();
  const desktop_obj= new NavDesktop();
  const laptop_obj = new LaptopsNotebooks();
  const component_obj= new NavComponents();
  const tablet_obj = new NavTablets();
  const software_obj = new NavSoftware();
  const phones_obj= new NavPhonesAndPDAs();
  const camera_obj = new NavCamera();
  const mp3_obj = new NavMP3Player();

  const checkout_obj = new checkout();
  const information_obj = new Infomation();
  const logout_obj = new LogoutPage();
it('RegisterPage', () => {
    register_obj.RegisterPage();
    
  });
  
it('LoginPage - In email not putting "@gmail.com" and entering correct Password', () => {
        
 
  login_obj1.LoginInMyAccount();
  login_obj1.NTLoginCredentials1();
});
it('LoginPage - Entering Wrong Email and Correct Password', () => {
        
  
  login_obj1.LoginInMyAccount();
  login_obj1.NTLoginCredentials2();
});

it('LoginPage - Entering correct Email and wrong Password', () => {
  
  
  login_obj1.LoginInMyAccount();
  login_obj1.NTLoginCredentials3();
}); 

it('LoginPage - Entering correct Email and leaving Password blank', () => {
  
 
  login_obj1.LoginInMyAccount();
  login_obj1.NTLoginCredentials4();
});

it('LoginPage - Entering correct Password and leaving Email blank', () => {
  
  
  login_obj1.LoginInMyAccount();
  login_obj1.NTLoginCredentials5();
});
it('LoginPage - Entering correct  Email and Password ', () => {
   
  login_obj1.LoginInMyAccount();
  login_obj1.PTLoginCredentialsAccept();
  
});
it('Homepage Button', () => {
  login_obj.visit();
  desktop_obj.desktop_click();
  desktop_obj.desktop_PC();
  login_obj.back_to_homepage();
});

it('Search Bar', () => {
  login_obj.visit();
  search_obj.search_tye();

});

it('Wrong Search ', () => {
  login_obj.visit();
  search_obj.search_wrong_type();
});

it('currency dollar', () => {
  login_obj.visit();
  login_obj.currency_dollar();
  
});
it('currency pound sterling', () => {
  login_obj.visit();
  login_obj.currency_pound_sterling();
  
});
it('currency euro', () => {
  login_obj.visit();
  login_obj.currency_euro();
  
});

it('Nav bar desktop', () => {
    login_obj.visit();
    desktop_obj.desktop_click();
    desktop_obj.desktop_PC();
    
  });

  it('Nav bar PC', () => {
    login_obj.visit();
    desktop_obj.desktop_Mac();
  });

  it('Nav bar Macs', () => {
    login_obj.visit();
    laptop_obj.laptop_notebook_click();
    laptop_obj.laptop_notebook_Macs();
  });

  it('Nav bar Windows', () => {
    login_obj.visit();
    laptop_obj.laptop_notebook_click();
    laptop_obj.laptop_notebook_Windows();
  });

  it('Nav Component Mice And Trackball', () => {
    login_obj.visit();
    component_obj.component_click();
    component_obj.component_mice_and_trackballs();
  });
  it('Nav Component Printers', () => {
    login_obj.visit();
    component_obj.component_click();
    component_obj.component_printers();
  });
  it('Nav Component Scanners', () => {
    login_obj.visit();
    component_obj.component_click();
    component_obj.component_scanners();
  });
  it('Nav Component Web Cameras', () => {
    login_obj.visit() ;
    component_obj.component_click();
    component_obj.componenet_web_cameras();
  });

  it('Nav Tablets ', () => {
    login_obj.visit();
    tablet_obj.nav_tablets_click();
  });

  it('Nav Software ', () => {
    login_obj.visit();
    software_obj.software_click();
  });

  it('Nav phones and pdas 1', () => {
    login_obj.visit();
    phones_obj.iphones_and_pdas_click();
    phones_obj.first_product();
  });

  it('Nav phones and pdas 2', () => {
    login_obj.visit();
    phones_obj.iphones_and_pdas_click();
    phones_obj.second_product();
  });

  it('Nav phones and pdas 3', () => {
    login_obj.visit();
    phones_obj.iphones_and_pdas_click();
    phones_obj.third_product();
  });

  it('Nav camera 1 ', () => {
    login_obj.visit();
    camera_obj.camera_click();
    camera_obj.camera_1();
  });

  it('Nav MP3 1 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_1();
  });

  it('Nav MP3 2 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_2();
  });

  it('Nav MP3 3 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_3();
  });

  it('Nav MP3 4 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_4();
  });

  it('Nav MP3 5 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_5();
  });

  // it('Nav MP3 6 ', () => {
  //   login_obj.visit();
  //   mp3_obj.mp3_click();
  //   mp3_obj.mp3_6();
  // });

  it('Nav MP3 7 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_7();
  });

  it('Nav MP3 8 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_8();
  });

  it('Nav MP3 9 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_9();
  });

  it('Nav MP3 10 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_10();
  });

  it('Nav MP3 11 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_11();
  });

  it('Nav MP3 12 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_12();
  });

  it('Nav MP3 13 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_13();
  });

  it('Nav MP3 14 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_14();
  });

  it('Nav MP3 15 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_15();
  });

  it('Nav MP3 16 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_16();
  });

  it('Nav MP3 17 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_17();
  });

  it('Nav MP3 18 ', () => {
    login_obj.visit();
    mp3_obj.mp3_click();
    mp3_obj.mp3_18();
  });

  it('adds product to cart and checkout Process', () => {
    login_obj1.LoginInMyAccount();
    login_obj1.PTLoginCredentialsAccept();
    phones_obj.iphones_and_pdas_click();
    phones_obj.first_product();
    checkout_obj.checkout_click();

});

  it('visits every lik at footer ', () => {
    information_obj.Infomation();
});

it('Logout Process',() =>{
  login_obj1.LoginInMyAccount();
  login_obj1.PTLoginCredentialsAccept();
    logout_obj.Logout();
    logout_obj.Clicking_on_Continue();
})

});