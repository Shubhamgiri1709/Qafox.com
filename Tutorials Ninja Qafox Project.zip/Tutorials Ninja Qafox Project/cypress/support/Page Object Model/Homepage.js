class Homepage {
    //visit the page 
    visit(){
        cy.visit("https://tutorialsninja.com/demo/index.php?route=common/home")
    }
    back_to_homepage(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=common/home'])[1]").click()
    }
    currency_euro(){
        cy.get("button.btn.btn-link.dropdown-toggle").click()
        cy.xpath("(//button[@class='currency-select btn btn-link btn-block'])[1]").click()
        cy.get('p.price').should('contain.text', '472.33€').and('be.visible')


    }
    currency_pound_sterling(){
        cy.get("button.btn.btn-link.dropdown-toggle").click()
        cy.xpath("(//button[@class='currency-select btn btn-link btn-block'])[2]").click()
        cy.get('p.price').should('contain.text', '£368.73').and('be.visible')
    }
    currency_dollar(){
        cy.get("button.btn.btn-link.dropdown-toggle").click()
        cy.xpath("(//button[@class='currency-select btn btn-link btn-block'])[3]").click()
        cy.get('p.price').should('contain.text', '$602.00').and('be.visible')
    }
       }
  
  export default Homepage;