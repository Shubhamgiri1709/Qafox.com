class NavCamera{
    camera_click(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=33'])[1]").click();
    }
    camera_1(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/product&path=33&product_id=30'])[1]").click();
        // there are no options avalible in the field due to which  the frther process of adding to cart cant be done .
        //cy.get("#input-option226").select(' --- Please Select --- ')
        cy.get("#input-quantity").click().type('{backspace}').type(2)
        cy.xpath("//button[@id='button-cart']").click()

    }
    camera_2(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/product&path=33&product_id=31'])[1]").click()
        cy.get("#input-quantity").click().type('{backspace}').type(2)
        cy.xpath("//button[@id='button-cart']").click()
        cy.contains('div','Success: You have added ')
        .should('exist')
        .and('be.visible')

    }
}
export default NavCamera