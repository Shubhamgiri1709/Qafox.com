class NavComponents{
    component_click(){
        cy.xpath("(//a[@class='dropdown-toggle'])[4]").click();
        
    }
    component_mice_and_trackballs(){
        cy.xpath("//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=25_29']").click()
        cy.contains('p', 'There are no products to list in this category.')
         .should('exist')  
         .and('be.visible'); 
        cy.get("a.btn.btn-primary").click()

    }
    component_monitors(){
        cy.xpath("//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=25_28']").click()

    }
    component_printers(){
        cy.xpath("//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=25_30']").click()
        cy.contains('p', 'There are no products to list in this category.')
         .should('exist')  
         .and('be.visible'); 
        cy.get("a.btn.btn-primary").click()
    }
    component_scanners(){
        cy.xpath("//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=25_31']").click()
        cy.contains('p', 'There are no products to list in this category.')
         .should('exist')  
         .and('be.visible'); 
        cy.get("a.btn.btn-primary").click()
    }
    componenet_web_cameras(){
        cy.xpath("//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=25_32']").click()
        cy.contains('p', 'There are no products to list in this category.')
         .should('exist')  
         .and('be.visible'); 
        cy.get("a.btn.btn-primary").click()
    }


}
export default NavComponents