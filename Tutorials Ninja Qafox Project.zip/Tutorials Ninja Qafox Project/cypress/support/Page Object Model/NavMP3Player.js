class NavMP3Player{
    mp3_click(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34'])[1]").click()
    }

    mp3_1(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_43'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()

    }
    mp3_2(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_44'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_3(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_47'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_4(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_48'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_5(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_49'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_7(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_50'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_8(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_51'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    // mp3_9(){
    //     cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_52'])[1]").click()
    //     cy.contains('p','There are no products to list in this category.')
    //     .should('exist')
    //     .and('be.visible')
    //     cy.get(".btn.btn-primary").click()
    // }
    mp3_10(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_53'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_11(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_54'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_12(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_55'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_13(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_56'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_14(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_38'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_15(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_37'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_16(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_39'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_17(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_40'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_18(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_41'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
    mp3_18(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=34_42'])[1]").click()
        cy.contains('p','There are no products to list in this category.')
        .should('exist')
        .and('be.visible')
        cy.get(".btn.btn-primary").click()
    }
}
export default NavMP3Player;