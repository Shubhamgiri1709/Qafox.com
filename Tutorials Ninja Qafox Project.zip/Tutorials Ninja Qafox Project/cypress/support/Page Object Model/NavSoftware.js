class NavSoftware{
    software_click(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=17'])[1]").click()
        cy.contains('p', 'There are no products to list in this category.')
         .should('exist')  
         .and('be.visible'); 
        cy.get("a.btn.btn-primary").click()

    }
}
export default NavSoftware