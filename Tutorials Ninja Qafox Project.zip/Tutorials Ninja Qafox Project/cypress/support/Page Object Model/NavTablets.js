class NavTablets{
    nav_tablets_click(){
        cy.xpath("(//a[@href='https://tutorialsninja.com/demo/index.php?route=product/category&path=57'])[1]").click()
    }
}
export default NavTablets