class searchBar{
    
    search_tye(){
        cy.get("input.form-control.input-lg").click().type('mac')
        cy.get("button.btn.btn-default.btn-lg").click()
        cy.url().should('include','mac')
        cy.contains('h2','Products meeting the search criteria').should('exist').and('be.visible')
    }
    search_wrong_type(){
        cy.get("input.form-control.input-lg").click().type('biryani')
        cy.get("button.btn.btn-default.btn-lg").click()
        cy.url().should('include','biryani')
        cy.contains('p','There is no product that matches the search criteria.').should('exist').and('be.visible')
    }
    search_bar_click(){
        cy.get("button.btn.btn-default.btn-lg").click()
    }


}
export default searchBar